
var Pagina;
var contenido;

function openPag(evt, pageName) {
    Pagina=pageName;
    // Declare all variables
    var i, tabcontent, tablinks;
    
    // Get all elements with class="tabcontent" and hide them
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
      tabcontent[i].style.display = "none";
    }
  
    // Get all elements with class="tablinks" and remove the class "active"
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
      tablinks[i].className = tablinks[i].className.replace(" active", "");
    }
  
    // Show the current tab, and add an "active" class to the button that opened the tab
    document.getElementById(pageName).style.display = "block";
    evt.currentTarget.className += " active";
    
  }

function abrir(event){
  let archivo= event.target.files[0];

  if(archivo){
    let reader = new FileReader();
    
    reader.onload= function(e){
      contenido= e.target.result;
      if(Pagina=="Pag1"){
        LimpiarEditor2("Editor1")
        document.getElementById("Editor1").innerText= contenido;
      }else if(Pagina=="Pag2"){
        LimpiarEditor2("Editor2")
        document.getElementById("Editor2").innerText=contenido;
      }else if(Pagina=="Pag3"){
        LimpiarEditor2("Editor3")
        document.getElementById("Editor3").innerText=contenido;
      }else if(Pagina=="Pag4"){
        LimpiarEditor2("Editor4")
        document.getElementById("Editor4").innerText=contenido;
      }
    };

    reader.readAsText(archivo);

  }else{
    window.alert("No se ha seleccionado un archivo")

  }
}

function LimpiarEditor2(idEditor){
  document.getElementById(idEditor).innerText="";
}

function LimpiarEditor(event,idEditor){
  document.getElementById(idEditor).innerText="";
}
  window.addEventListener("load",()=>{
    document.getElementById("archivoTexto").addEventListener("change",abrir);
  });

  

function Analizar(event){
  var url= 'http://localhost:4000/Analizar/';

  if(contenido==null){
    contenido="No se muestra el contenido :(";
  }
  
  $.post(url,{text:contenido},function(data,status){
    if(status.toString()=="success"){
        alert("El resultado es: "+data.toString());
    }else{
        alert("Error estado de conexion:"+status);
    }
});
}
  

  

  document.getElementById("Abierto").click();
  