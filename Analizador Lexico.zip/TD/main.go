package main

import (
	"fmt"
	"log"
	"net/http"
	"time"
)

type mensaje struct {
	msg string
}

func (m mensaje) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	fmt.Fprint(w, m.msg)
}

func main() {

	mux := http.NewServeMux()
	fs := http.FileServer(http.Dir("Frontend"))

	mux.Handle("/", fs)

	server := &http.Server{
		Addr:           ":8088",
		Handler:        mux,
		ReadTimeout:    10 * time.Second,
		WriteTimeout:   10 * time.Second,
		MaxHeaderBytes: 1 << 20,
	}

	log.Println("Listening...")
	log.Fatal(server.ListenAndServe())
}
