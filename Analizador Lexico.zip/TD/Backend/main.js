var AnalizadorLPython= require("./AnalizadorPY/AnalisisL");
var aVer= "public , class IdentificadorClase{ int valor= Variable}\n"+
"system.out.println \n"+
"Simbolos: { } ( ) , ; = []&&||![^<>>=<===!=+-*/++---"+
"Cadenas: \"Hola\"  'Como estás' m+ ";

AnalizadorLPython(aVer);
