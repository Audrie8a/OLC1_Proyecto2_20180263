var AnalizadorLPython= require("./AnalizadorPY/AnalisisL");
var AnalizadorSPython= require("./AnalizadorPY/AnalisisS");
var AnalisisL="";
var aVer=""+
"public class Identificador{\n"+
    " /*Solo quiero ver: \n lo de los comentarios */ \n"+
"}\n"+
"public interface Identificador{\n"+

"}";


AnalisisL=AnalizadorLPython(aVer);
AnalizadorSPython(AnalisisL);

