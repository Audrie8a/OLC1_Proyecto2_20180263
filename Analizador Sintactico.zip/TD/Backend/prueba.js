function saludar(req,res){
    return res.send("hola soy Audrie");
}

module.exports= saludar;