var AnalizadorLPython= require("./AnalizadorPY/AnalisisL");

function Analizar(Texto){
    //var Python= AnalizadorLPython(Texto);
    //return "Analizando "+ Python;

}

module.exports= Analizar;