const Express= require("express");
const Router = Express.Router();


const index = require('./prueba');
Router.get('/prueba', index);


module.exports=Router;