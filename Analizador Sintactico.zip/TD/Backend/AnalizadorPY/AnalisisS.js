const { response, text } = require("express");
const Main = require("./AnalisisL");


var ErrorSintactico = false;
var listError = [];
var actualT;
var siguienteT;
var finalT;
var contador = 0;
var Token;
var tokensArbol = [];
var lstComentarios = [];


var Tipo = ['int', 'boolean', 'double', 'string', 'char'];
var Valor = ['Cadena', 'Caracter', 'Numero', 'Decimal', 'Booleano']
var Operador = ['OperadorL', 'OperadorR', 'OperadorA'];

function Main2(Lista) {
    Token = RetenerComentarios(Lista);
    AnalisisSintactico(Lista);
    return tokensArbol;
}

//Listo
function AnalisisSintactico(Tokens) {
    LimpiarLista(listError);
    actualT = Tokens[contador];
    siguienteT = Token[contador + 1];
    finalT = Token[contador + 2];
    contador = 0;
    INI();
    tokensArbol = ContenidoArbol(tokensArbol);
    return tokensArbol;

}

//Listo
function INI() {
    Parea('public', 'no');
    Principal();
    Mas();
}

//Listo
function Principal() {
    if (actualT[3] == 'class') {
        Parea('class', 'no');
        Parea('id', actualT[2]);
        Parea('{', 'no');
        ContenidoC();
        Parea('}', 'no');
    }
    else if (actualT[3] == 'interface') {
        Parea('interface', 'no');
        Parea('id', actualT[2]);
        Parea('{', 'no');
        ContenidoI();
        Parea('}', 'no');
    }
    else {
        ErrorSintactico = true;
        Parea('', 'class o interface');
        Principal();
    }
}

//Listo
function Mas() {
    if (actualT[3] == 'public') {
        INI();
    }
    else {
        return;
    }
}

//Listo
function ContenidoC() {
    if (actualT[3] == 'public') {
        Parea('public', 'no');
        MF();
        ContenidoC();
    }
    else if (actualT[2] == 'identificador' || Tipo.find(Element => actualT[3] == Element) != null) {
        variables();
        ContenidoC();
    }
    else {
        return;
    }

}

//Listo
function MF() {
    if (Tipo.find(Element => actualT[3] == Element) != null) {
        Parea(Tipo.find(Element => actualT[3] == Element), 'no');
        Parea('id', actualT[2]);
        Parea('(', 'no');
        Parametros();
        Parea(')', 'no');
        DAF();
    }
    else if (actualT[3] == 'void') {
        Parea('void', 'no');
        Parea('id', actualT[2]);
        Parea('(', 'no');
        Parametros();
        Parea(')', 'no');
        DAM();
    }
    else if (actualT[3] == 'static') {
        Parea('static', 'no');
        Parea('void', 'no');
        Parea('main', 'no');
        Parea('(', 'no');
        Parea('string', 'no');
        Parea('[', 'no');
        Parea(']', 'no');
        Parea('args', 'no');
        Parea(')', 'no');
        Parea('{', 'no');
        Instrucciones();
        Parea('}', 'no');
    }
    else {
        ErrorSintactico = true;
        listError.push([actualT[3], 'tipo dato, void o static']);
        Parea('', 'tipo dato, void o static');
        MF();
    }
}

//Listo
function Instrucciones() {
    if (actualT[3] == 'for' || actualT[3] == 'while' || actualT[3] == 'do' || actualT[3] == 'if') {
        Sentencias();
        MasInstrucciones();
    } else if (actualT[2] == 'identificador' && siguienteT[3] == '(') {
        LlamadaMF();
        Parea(';', 'no');
        MasInstrucciones();
    } else if (actualT[2] == 'identificador') {
        variables();
        MasInstrucciones();
    }
    else if (actualT[3] == 'system.out.print' || actualT[3] == 'system.out.println') {
        Print();
        MasInstrucciones();
    } else {
        ErrorSintactico = true;
        listError.push([actualT[3], 'tipo dato, void o static']);
        Parea('', 'for, while, do, if, identificador, system.out.print, system.out.println,id o variable');
        Instrucciones();
    }
}

//Listo
function MasInstrucciones() {
    if (actualT[3] == 'for' || actualT[3] == 'while' || actualT[3] == 'do' || actualT[3] == 'if' || actualT[2] == 'identificador'
        || actualT[3] == 'system.out.print' || actualT[3] == 'system.out.println') {
        Instrucciones();
    } else {
        return;
    }
}

//Listo
function Sentencias() {
    if (actualT[3] == 'for' || actualT[3] == 'while' || actualT[3] == 'do') {
        SentenciasR();
    } else if (actualT[3] == 'if') {
        SentenicasC();
    } else {
        ErrorSintactico = true;
        listError.push([actualT[3], 'for, while, do o if']);
        Parea('', 'tipo dato, void o static');
    }
}

//Listo
function SentenciasR() {
    if (actualT[3] == 'for') {
        Parea('for', '');
        Parea('(', 'no');
        DEC();
        EXP();
        Parea(';', 'no');
        EXP();
        Parea(')', 'no');
        Parea('{', 'no');
        Instrucciones();
        SBCR();
        Parea('}', 'no');

    } else if (actualT[3] == 'while') {
        Parea('while', 'no');
        Parea('(', 'no');
        EXP();
        Parea(')', 'no');
        Parea('{', 'no');
        Instrucciones();
        SBCR();
        Parea('}', 'no');
    } else if (actualT[3] == 'do') {
        Parea('do', 'no');
        Parea('{', 'no');
        Instrucciones();
        SBCR();
        Parea('}', 'no');
        Parea('while', 'no');
        Parea('(', 'no');
        EXP();
        Parea(')', 'no');
        Parea(';', 'no');
    } else {
        ErrorSintactico = true;
        listError.push([actualT[3], 'for, while o do']);
        Parea('', 'for, while o do');
        SentenciasR();
    }
}

//Listo
function SentenicasC() {
    Parea('if', 'no');
    Parea('(', 'no');
    EXP();
    Parea(')', 'no');
    Parea('{', 'no');
    Instrucciones();
    SBCR();
    Parea('}', 'no');
    Elif();
    Else();
}

//Listo
function Else() {
    if (actualT[3] == 'else') {
        Parea('else', 'no');
        Parea('{', 'no');
        Instrucciones();
        Parea('}', 'no');
    } else {
        return;
    }
}

//Listo
function Elif() {
    if (actualT[3] == 'else') {
        Parea('else', 'no');
        SentenicasC();
    } else {
        return;
    }
}

//Listo
function DEC() {
    Parea(Tipo.find(Element => actualT[3] == Element), 'no');
    Parea('id', actualT[2]);
    MasVariables();
}

//Listo
function SBCR() {
    if (actualT[3] == 'break') {
        Parea('break', 'no');
        Parea(';', 'no');
    } else if (actualT[3] == 'continue') {
        Parea('continue', 'no')
        Parea(';', 'no');
    } else if (actualT[3] == 'return') {
        Parea('return', 'no');
        opcion();
        Parea(';', 'no');
    } else {
        return;
    }
}

//Listo
function Print() {
    if (actualT[3] == 'system.out.print') {
        Parea('system.out.print', 'no');
    } else if (actualT[3] == 'system.out.println') {
        Parea('system.out.println', 'no');
    } else {
        ErrorSintactico = true;
        listError.push([actualT[3], 'system.out.println o system.out.print']);
        Parea('', 'system.out.println o system.out.print');
    }
    Parea('(', 'no');
    EXP();
    Parea(')', 'no');
    Parea(';', 'no');
}

//Listo
function DAF() {
    if (actualT[3] == '{') {
        Parea('{', 'no');
        Instrucciones();
        Parea('return', 'no');
        opcion();
        Parea(';', 'no');
        Parea('}', 'no');
    }
    else if (actual[3] == ';') {
        Parea(';', 'no');
    }
    else {
        ErrorSintactico = true;
        listError.push([actualT[3], '{ ó ;']);
        Parea('', '{ ó ;');
        DAF();
    }
}

//Listo
function opcion() {
    let prueba = Operador.find(Element => siguienteT[2] == Element);
    let prueba2 = Operador.find(Element => actualT[2] == Element);
    let prueba3 = Operador.find(Element => finalT[2] == Element);
    if (prueba == null && prueba2 == null && prueba3 == null) {
        if (actualT[2] == 'identificador' && siguienteT[3] == '(') {
            LlamadaMF();
        }
        else {
            VAL();
        }
    }
    else if (prueba != null || prueba2 != null || prueba3 != null) {
        EXP();
    }
    else {
        ErrorSintactico = true;
        listError.push([actualT[3], 'id, valor o expresion ']);
        Parea('', '{ ó ;');
        opcion();
    }

}

//Listo
function EXP() {
    if (actualT[3] == '(') {
        Parea('(', 'no');
        EXP();
        Parea(')', 'no');
        MEXP();
    }
    else if (actualT[3] == '-' || actual[2] == 'identificador' || Valor.find(Element => actualT[2] == Element) != null) {
        SIMB();
        VAL();
        SIMB2();
        Parea('op', actualT[2]);
        SIMB();
        VAL();
        SIMB2();
        MEXP();
    } else {
        ErrorSintactico = true;
        listError.push([actualT[3], '- , identificador, Operador ó (']);
        Parea('', '');
        EXP();
    }

}

//Listo
function MEXP() {
    if (Operador.find(Element => actualT[2] == Element) != null) {
        Parea(Operador.find(Element => actualT[2] == Element), 'no');
        EXP();
    } else {
        return;
    }
}

//-----------------------------------------------------------------------------------------------------------------
function EXP2() {
    let prueba2 = Operador.find(Element => siguienteT[2] == Element);
    let prueba = Operador.find(Element => actualT[2] == Element);
    let prueba3 = Operador.find(Element => finalT[2] == Element);

    if (prueba2 == null && prueba3 != null && prueba != null) {
        if (actualT[3] == '-') {
            EXPA();
        }
        else if (actualT[3] == '!') {
            EXPL();
        }

    }
    else if (prueba == null && prueba2 != null && prueba3 != null) {
        if (finalT[3] == '!') {
            EXPL();
        }
        else {
            EXPA();
        }

    }
    else if (prueba == null && prueba2 != null && prueba3 == null) {
        if (siguienteT[2] == 'OperadorL') {
            EXPL();
        }
        else if (siguienteT[2] == 'OperadorR') {
            EXPR();
        }
        else if (siguienteT[2] == 'OperadorA') {
            EXPA();
        }
    }
    else if (actualT[3] == '(') {
        Parea('(', 'no');
        EXP();
        Parea(')', 'no');
    }
    else if (prueba == null && prueba2 == null && prueba3) {
        //ERROR
    }
}
function EXPL() {
    if (null) {
        VALR();
        Parea('opr', actualT[2]);
        VALR();
    }
    else if (actualT[3] == '(') {
        Parea('(', 'no');
        EXPR();
        Parea('(', 'no');
    }
    else {
        ErrorSintactico = true;
        listError.push([actualT[3], 'Expresion relacional o expresion lógica ']);
        Parea('', '{ ó ;');
        EXPL();
    }
}
function VALR() {
    let prueba2 = Operador.find(Element => siguienteT[2] == Element);
    let prueba = Operador.find(Element => actualT[2] == Element);
    let prueba3 = Operador.find(Element => finalT[2] == Element);
    if (prueba == 'OperadorA' || prueba2 == 'OperadorA' || prueba3 == 'OperacorA') {
        EXPA();
    }
    else if (siguienteT[2] == 'OperadorR') {
        VAL();
    }
}
function EXPR() {
    if (actualT[3] == '(') {
        Parea('(', 'no');
        EXPR();
        Parea(')', 'no');
    }
    else {
        VALR()
        VALR();
    }
}
//Listo
function EXPA() {
    SIMB();
    EXPEA();
}
//Listo
function EXPEA() {
    let prueba2 = Operador.find(Element => siguienteT[2] == Element);
    let prueba = Operador.find(Element => actualT[2] == Element);
    let prueba3 = Operador.find(Element => finalT[2] == Element);
    let condicion = prueba2 != null || prueba != null || prueba3 != null;
    if (actualT[3] == '(') {
        Parea('(', 'no');
        EXPA();
        Parea(')', 'no');
        MEA();
    } else if (actualT[2] == 'identificador' || Valor.find(Element => actualT[2] == Element) != null && condicion == true) {
        VALA();
        SIMB2();
        MEA();
    }
    else {
        ErrorSintactico = true;
        listError.push([actualT[3], '(coma, id o valor']);
        Parea('', '');
        EXPEA();
    }

}
//Listo
function MEA() {
    if (actualT[2] == 'OperadorA') {
        Parea('opa', actualT[2]);
        EXPA();
        MEA();
    }
    else {
        return;
    }
}
//Listo
function VALA() {
    if (siguienteT[2] != 'OperadorA') {
        EXP();
    } else if (actualT[2] == 'identificador' || Valor.find(Element => actualT[2] == Element) == null && siguienteT[2] == 'OperadorA') {
        VAL();
    }
    else {
        ErrorSintactico = true;
        listError.push([actualT[3], 'EXP, id o Valor']);
        Parea('', '');
        VALA();
    }

}
//--------------------------------------------------------------------------------------------------------------
//Listo
function SIMB2() {
    if (actualT[3] == '++' || actualT[3] == '--') {
        Parea('opa', actualT[2]);
    }
    else {
        return;
    }
}

//Listo
function VAL() {
    if (Valor.find(Element => siguienteT[2] == Element)) {
        Parea(Tipo.find(Element => actualT[3] == Element), 'no');
    }
    else if (actualT[2] == 'identificador') {
        Parea('id', actualT[2]);
    }
    else {
        ErrorSintactico = true;
        listError.push([actualT[3], 'id o valor']);
        Parea('', '');
        opcion();
    }
}

//Listo
function LlamadaMF() {
    Parea('id', actualT[2]);
    Parea('(', 'no');
    Parametros();
    Parea(')', 'no');
}

function SIMB() {
    if (actualT[3] == '-') {
        Parea('-', 'no');
    } else {
        return;
    }
}
//Listo
function DAM() {
    if (actualT[3] == '{') {
        Parea('{', 'no');
        Instrucciones();
        Parea('}', 'no');
    }
    else if (actualT[3] == ';') {
        Parea(';', 'no');
    }
    else {
        ErrorSintactico = true;
        listError.push([actualT[3], '{ ó ;']);
        Parea('', '{ ó ;');
        DAM();
    }
}

//Listo
function Parametros() {
    if (Tipo.find(Element => actualT[3] == Element) != null) {
        Parea(Tipo.find(Element => actualT[3] == Element), 'no');
        Parea('id', actualT[2]);
        MasParametros();
    }
    else {
        ErrorSintactico = true;
        Parea('', 'Tipo');
        Parametros();
    }
}

//Listo
function MasParametros() {
    if (actualT[3] == ',') {
        Parea(',', 'no');
        Parametros();
    }
    else {
        return;
    }
}

//Listo     Revisar Gramática 
function variables() {
    if (Tipo.find(Element => actualT[3] == Element) != null) {
        Parea(Tipo.find(Element => actualT[3] == Element), 'no');
        Parea('id', actualT[2]);
        MasVariables();
    }
    else if (actualT[2] == 'identificador') {
        Parea('id', actualT[2]);
        Parea('=', 'no');
        opcion();
        Parea(';', 'no');
    } else {
        ErrorSintactico = true;
        listError.push([actualT[3], 'Tipo o id']);
        Parea('', 'Tipo o id');
        variables();
    }
}

//Listo
function MasVariables() {
    if (actualT[3] == ',') {
        Parea(',', 'no');
        Parea('id', actualT[2]);
        MasVariables();
    }
    else if (actualT[3] == '=') {
        Parea('=', 'no');
        opcion();
        opcion2();
    }
    else if (actualT[3] == ';') {
        Parea(';', 'no');
    }
    else {
        ErrorSintactico = true;
        listError.push([actualT[3], 'coma, = ó ;']);
        Parea('', '');
        MasVariables();
    }
}

//Listo
function opcion2() {
    if (actualT[3] == ',') {
        Parea(',', 'no');
        Parea('id', actualT[2]);
        MasVariables();
    }
    else if (actualT[3] == ';') {
        Parea(';', 'no');
    }
    else {
        ErrorSintactico = true;
        listError.push([actualT[3], ', ó ;']);
        Parea('', '');
        opcion2();
    }
}

//Listo
function ContenidoI() {
    Parea(Tipo.find(Element => actualT[3] == Element), 'no');
    Parea('id', actualT[3]);
    if (actualT[3] == ',' || actualT[3] == '=' || actualT[3] == ';') {
        DEC();
        MDEC();
    } else if (actualT[3] == '(') {
        DECMF();
        MDECMF();
    } else {
        ErrorSintactico = true;
        listError.push([actualT[3], 'coma, =, ; ó (']);
        Parea('', '');
        if (contador < Token.length - 1) {

            ContenidoI();
        }
    }
}

//Listo
function MDEC() {
    if (Tipo.find(Element => actualT[3] == Element) != null) {
        DEC();
        MDEC();
    }
    else {
        return;
    }
}

//Listo
function DECMF() {
    Parea(Tipo.find(Element => actualT[3] == Element), 'no');
    Parea('id', actualT[2]);
    Parea('(', 'no');
    Parametros();
    Parea(')', 'no');
    Parea(';', 'no');

}

//Listo
function MDECMF() {
    if (Tipo.find(Element => actualT[3] == Element) != null) {
        DECMF();
        MDECMF();
    } else {
        return;
    }
}

//Listo
function Parea2(token, tipoToken) {
    if (contador < Token.length - 1) {
        if (ErrorSintactico == true) {
            contador++;
            actualT = Token[contador];
            siguienteT = Token[contador + 1];
            if (actualT[3] == ';' || actualT[3] == '}') {
                contador++;
                actualT = Token[contador];
                siguienteT = Token[contador + 1];
                finalT = Token[contador + 2];
                ErrorSintactico = false;
            }

        }
        else {
            if (tipoToken == 'no') {
                if (actualT[3] == token) {
                    tokensArbol.push(Token[contador]);
                    contador++;
                    actualT = Token[contador];
                    siguienteT = Token[contador + 1];
                    finalT = Token[contador + 2];
                } else {                                          //Lo que se verá al imprimir 
                    listError.push([actualT[3], token]);    //Error Sintáctico en: actualT, Se esperaba: token;
                    ErrorSintactico = true;
                }
            } else if (token == 'id') {
                if (actualT[2] == "identificador") {
                    tokensArbol.push(Token[contador]);
                    contador++;
                    actualT = Token[contador];
                    siguienteT = Token[contador + 1];
                    finalT = Token[contador + 2];
                }
                else {                                          //Lo que se verá al imprimir 
                    listError.push([actualT[3], tipoToken]);    //Error Sintáctico en: actualT, Se esperaba: token;
                    ErrorSintactico = true;
                }
            } else if (token == 'opa') {
                if (actualT[2] == 'OperadorA') {
                    tokensArbol.push(Token[contador]);
                    contador++;
                    actualT = Token[contador];
                    siguienteT = Token[contador + 1];
                    finalT = Token[contador + 2];
                }
                else {                                          //Lo que se verá al imprimir 
                    listError.push([actualT[3], tipoToken]);    //Error Sintáctico en: actualT, Se esperaba: token;
                    ErrorSintactico = true;
                }
            } else if (token == 'opr') {
                if (actualT[2] == 'OperadorR') {
                    tokensArbol.push(Token[contador]);
                    contador++;
                    actualT = Token[contador];
                    siguienteT = Token[contador + 1];
                    finalT = Token[contador + 2];
                }
                else {                                          //Lo que se verá al imprimir 
                    listError.push([actualT[3], tipoToken]);    //Error Sintáctico en: actualT, Se esperaba: token;
                    ErrorSintactico = true;
                }
            } else if (token == 'opl') {
                if (actualT[2] == 'OperadorL') {
                    tokensArbol.push(Token[contador]);
                    contador++;
                    actualT = Token[contador];
                    siguienteT = Token[contador + 1];
                    finalT = Token[contador + 2];
                }
                else {                                          //Lo que se verá al imprimir 
                    listError.push([actualT[3], tipoToken]);    //Error Sintáctico en: actualT, Se esperaba: token;
                    ErrorSintactico = true;
                }
            } else if (token == 'op') {
                if (Operador.find(Element => actualT[2] == Element) != null) {
                    tokensArbol.push(Token[contador]);
                    contador++;
                    actualT = Token[contador];
                    siguienteT = Token[contador + 1];
                    finalT = Token[contador + 2];
                }
                else {                                          //Lo que se verá al imprimir 
                    listError.push([actualT[3], tipoToken]);    //Error Sintáctico en: actualT, Se esperaba: token;
                    ErrorSintactico = true;
                }
            }

        }
    }

}

function Parea(token, tipoToken) {
    if (contador < Token.length - 1) {
        if (ErrorSintactico == true) {
            contador++;
            actualT = Token[contador];
            siguienteT = Token[contador + 1];
            if (actualT[3] == ';' || actualT[3] == '}') {
                contador++;
                actualT = Token[contador];
                siguienteT = Token[contador + 1];
                finalT = Token[contador + 2];
                ErrorSintactico = false;
            }
        }
        else {
            if (tipoToken == 'no') {
                if (actualT[3] == token) {
                    tokensArbol.push(Token[contador]);
                    contador++;
                    actualT = Token[contador];
                    siguienteT = Token[contador + 1];
                    finalT = Token[contador + 2];
                } else {                                          //Lo que se verá al imprimir 
                    listError.push([actualT[3], token]);    //Error Sintáctico en: actualT, Se esperaba: token;
                    ErrorSintactico = true;
                }
            } else if (token == 'id') {
                if (actualT[2] == "identificador") {
                    tokensArbol.push(Token[contador]);
                    contador++;
                    actualT = Token[contador];
                    siguienteT = Token[contador + 1];
                    finalT = Token[contador + 2];
                }
                else {                                          //Lo que se verá al imprimir 
                    listError.push([actualT[3], tipoToken]);    //Error Sintáctico en: actualT, Se esperaba: token;
                    ErrorSintactico = true;
                }
            } else if (token == 'op') {
                if (Operador.find(Element => actualT[2] == Element) != null) {
                    tokensArbol.push(Token[contador]);
                    contador++;
                    actualT = Token[contador];
                    siguienteT = Token[contador + 1];
                    finalT = Token[contador + 2];
                }
                else {                                          //Lo que se verá al imprimir 
                    listError.push([actualT[3], tipoToken]);    //Error Sintáctico en: actualT, Se esperaba: token;
                    ErrorSintactico = true;
                }
            }

        }
    }

}

function LimpiarLista(Lista) {
    let count = 0;
    while (count < Lista.length) {
        Lista.pop();
        count++;
    }
}

function RetenerComentarios(Lista) {
    let Nuevalista = [];
    Lista.forEach(element => {
        if (element[2] !== 'Comentario') {
            Nuevalista.push(element);
        } else {
            lstComentarios.push(element);
        }
    });

    return Nuevalista;
}

function comparar(a, b) { return a - b; }
function ContenidoArbol(Lista) {
    lstComentarios.forEach(element => {
        Lista.push(element);
    });

    Lista.sort((a, b) => {
        if (a[0] < b[0]) {
            return -1;
        }
        if (a[0] > b[0]) {
            return 1;
        }

        return 0;
    });

    return Lista;
}

module.exports = Main2;