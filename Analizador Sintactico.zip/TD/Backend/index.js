const express = require('express');
const cors = require('cors');
var bodyParser = require("body-parser");
const app = express();
const rutas = require('./rutas');
const { Router, text } = require('express');
var Analizador= require('./Analisis');

var bodyParser = require("body-parser");



//Variables de Entorno
const ip   = process.env.NODEIP || "182.18.7.7";
const port = process.env.NODEPORT || 4000;



/*app.get('/getCurso/', function (req, res) {
    console.log("Entro una peticion REST");
    res.send(JSON.stringify( {Nombre: "Compiladores 1 seccion A"} ));
});

app.listen(port,ip, () => {
    console.log('IP: %s PORT: %d', ip, port);
});
*/

//Creando Ruta
app.set('port',4000);
app.use(bodyParser.json());
app.use(cors());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(rutas);

app.post('/Analizar/',function(req,res){
    var entrada=req.body.text;
    var respuesta= Analizador(entrada);
    res.send(respuesta.toString());
});

app.get('/', (req, res)=>{
    res.send("Holi");    
});



//Levantando el Servidor
app.listen(port, function(){
    console.log('Listen in port'+port)

    var respuesta= Analizador("for 8 a \n");
    console.log(respuesta);
});


